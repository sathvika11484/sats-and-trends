"""
This script analyzes global life expectancy data to explore human longevity
trends over time. It generates visualizations and calculates statistical
moments for life expectancy distributions.
"""

import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns


def plot_relational_plot(df):
    """
    Creates a scatter plot showing the progress of Life Expectancy
    over the years.
    """
    plt.figure(figsize=(8, 6))
    sns.scatterplot(data=df, x='Year', y='Life_Expectancy', alpha=0.3)
    plt.title('Global Progress: Life Expectancy Over Time')
    plt.xlabel('Year')
    plt.ylabel('Life Expectancy (Years)')
    plt.tight_layout()
    plt.savefig('relational_plot.png')
    plt.close()
    return


def plot_categorical_plot(df):
    """
    Creates a bar plot showing average Life Expectancy for the top 10
    highest-ranking entities in the dataset.
    """
    plt.figure(figsize=(12, 6))
    top_entities = df.groupby('Entity')['Life_Expectancy'].mean()
    top_entities = top_entities.sort_values(ascending=False).head(10)

    sns.barplot(
        x=top_entities.index,
        y=top_entities.values,
        hue=top_entities.index,
        palette='magma',
        legend=False
    )
    plt.title('Top 10 Entities by Average Life Expectancy')
    plt.xlabel('Country/Entity')
    plt.ylabel('Average Life Expectancy (Years)')
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.savefig('categorical_plot.png')
    plt.close()
    return


def plot_statistical_plot(df):
    """
    Creates a box plot to visualize the distribution of Life Expectancy
    for a sample of major countries.
    """
    plt.figure(figsize=(10, 6))
    # Filter for a few major countries to show distribution variety
    sample_entities = ['United Kingdom', 'United States', 'India', 'China']
    df_subset = df[df['Entity'].isin(sample_entities)]

    sns.boxplot(data=df_subset, x='Entity', y='Life_Expectancy')
    plt.title('Statistical Distribution of Longevity for Major Entities')
    plt.xlabel('Country')
    plt.ylabel('Life Expectancy (Years)')
    plt.tight_layout()
    plt.savefig('statistical_plot.png')
    plt.close()
    return


def statistical_analysis(df, col: str):
    """
    Calculates Mean, Standard Deviation, Skewness, and Excess Kurtosis
    for the specified column.
    """
    mean = df[col].mean()
    stddev = df[col].std()
    skew = df[col].skew()
    excess_kurtosis = df[col].kurtosis()

    return mean, stddev, skew, excess_kurtosis


def preprocessing(df):
    """
    Cleans data, renames long columns, and provides an initial overview.
    """
    # Rename the very long column name from the CSV
    target_col = 'Period life expectancy at birth - Sex: total - Age: 0'
    df = df.rename(columns={target_col: 'Life_Expectancy'})

    print("--- Dataset Overview ---")
    print(df.head())

    # Drop missing values to ensure statistical validity
    df = df.dropna(subset=['Life_Expectancy', 'Year', 'Entity'])

    return df


def writing(moments, col):
    """
    Interprets the statistical moments for the report.
    """
    mean, stddev, skew, excess_kurtosis = moments

    print(f'\nFor the attribute {col}:')
    print(f'Mean = {mean:.2f}, '
          f'Standard Deviation = {stddev:.2f}, '
          f'Skewness = {skew:.2f}, and '
          f'Excess Kurtosis = {excess_kurtosis:.2f}.')

    # Distribution interpretation
    skew_type = "not skewed"
    if skew > 0.5:
        skew_type = "right skewed"
    elif skew < -0.5:
        skew_type = "left skewed"

    kurt_type = "mesokurtic"
    if excess_kurtosis > 1:
        kurt_type = "leptokurtic"
    elif excess_kurtosis < -1:
        kurt_type = "platykurtic"

    print(f'The data was {skew_type} and {kurt_type}.')
    return


def main():
    """
    Main execution pipeline for Sathvika's Life Expectancy Data.
    """
    df = pd.read_csv('data.csv')
    df = preprocessing(df)

    col = 'Life_Expectancy'

    plot_relational_plot(df)
    plot_categorical_plot(df)
    plot_statistical_plot(df)

    moments = statistical_analysis(df, col)
    writing(moments, col)
    return


if __name__ == '__main__':
    main()
