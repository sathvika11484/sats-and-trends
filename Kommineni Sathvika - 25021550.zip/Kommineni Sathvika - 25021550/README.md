# Statistics and Trends Assignment
This is the template repository for the statistics and trends assignment.
You should create a personal repository from this template repository
(there is a green box with a link in the top right).
Ensure that the file `statistics_and_trends.py` is present and functional, with your downloaded data
in the `data.csv` file.